"""Esquemas del asistente de IA."""
from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


class AssistantMessageRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    role: str
    content: str
    source: str | None = None
    created_at: datetime


class ChatResponse(BaseModel):
    reply: str
    source: str  # ai | heuristic
    created_at: datetime


class AssistantStatus(BaseModel):
    enabled: bool
    configured: bool
    model: str
    base_url: str
