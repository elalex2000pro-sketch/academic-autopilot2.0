"""Academic Autopilot - Backend API."""
__version__ = "0.1.0"
