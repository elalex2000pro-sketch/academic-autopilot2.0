"""Endpoints del asistente de IA (chat de organizacion del estudio)."""
from __future__ import annotations

from fastapi import APIRouter, Query, status
from sqlalchemy import delete, select

from app.api.deps import CurrentUser, DbSession
from app.core.config import settings
from app.models.assistant_message import AssistantMessage
from app.schemas.assistant import (
    AssistantMessageRead,
    AssistantStatus,
    ChatRequest,
    ChatResponse,
)
from app.services import ai_service
from app.services.realtime import notify

router = APIRouter(prefix="/assistant", tags=["assistant"])


@router.get("/status", response_model=AssistantStatus)
async def assistant_status(current_user: CurrentUser) -> AssistantStatus:
    return AssistantStatus(
        enabled=settings.ai_enabled,
        configured=settings.ai_configured,
        model=settings.ai_model,
        base_url=settings.ai_base_url,
    )


@router.get("/messages", response_model=list[AssistantMessageRead])
async def list_messages(
    current_user: CurrentUser,
    db: DbSession,
    limit: int = Query(50, ge=1, le=200),
) -> list[AssistantMessage]:
    result = await db.execute(
        select(AssistantMessage)
        .where(AssistantMessage.user_id == current_user.id)
        .order_by(AssistantMessage.created_at.desc())
        .limit(limit)
    )
    return list(reversed(list(result.scalars().all())))


@router.post("/chat", response_model=ChatResponse)
async def chat(
    payload: ChatRequest, current_user: CurrentUser, db: DbSession
) -> ChatResponse:
    # Historial reciente (orden cronologico) para dar contexto al modelo.
    result = await db.execute(
        select(AssistantMessage)
        .where(AssistantMessage.user_id == current_user.id)
        .order_by(AssistantMessage.created_at.desc())
        .limit(settings.ai_history_limit)
    )
    recent = list(reversed(list(result.scalars().all())))
    history = [
        {"role": m.role, "content": m.content}
        for m in recent
        if m.role in ("user", "assistant")
    ]

    db.add(AssistantMessage(user_id=current_user.id, role="user", content=payload.message))
    await db.commit()

    reply, source = await ai_service.generate_reply(db, current_user, payload.message, history)

    assistant_message = AssistantMessage(
        user_id=current_user.id, role="assistant", content=reply, source=source
    )
    db.add(assistant_message)
    await db.commit()
    await db.refresh(assistant_message)

    notify(current_user.id, "assistant", {"action": "message", "id": str(assistant_message.id)})
    return ChatResponse(
        reply=reply, source=source, created_at=assistant_message.created_at
    )


@router.delete("/messages", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def clear_messages(current_user: CurrentUser, db: DbSession) -> None:
    await db.execute(delete(AssistantMessage).where(AssistantMessage.user_id == current_user.id))
    await db.commit()
    notify(current_user.id, "assistant", {"action": "cleared"})
