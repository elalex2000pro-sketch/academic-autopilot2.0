"""Capa API (FastAPI)."""
