"""Servicio del asistente de IA (organizacion del estudio).

Se conecta a un modelo servido por una API compatible con la de OpenAI (Ollama,
LM Studio, OpenAI, Groq...). Si el modelo no esta disponible, cae a un motor de
recomendaciones heuristico para seguir siendo util sin conexion.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.logging import get_logger
from app.db.base import utcnow
from app.models.course import Course
from app.models.enums import TaskStatus
from app.models.grade import Grade
from app.models.schedule_block import ScheduleBlock
from app.models.task import Task
from app.models.timetable_entry import TimetableEntry
from app.models.user import User

logger = get_logger(__name__)

_DAYS = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"]

_SYSTEM_PROMPT = (
    "Eres el asistente academico de 'Academic Autopilot', especializado en "
    "organizacion del estudio y gestion de tareas. Ayudas al estudiante a decidir "
    "CUANDO empezar a estudiar, como repartir el tiempo, priorizar y planificar su semana. "
    "Responde SIEMPRE en espanol, breve y accionable (pocas frases o una lista corta de pasos). "
    "No inventes datos: usa solo el CONTEXTO del estudiante. Cuando recomiendes horarios, "
    "basa las horas en su disponibilidad y en la fecha de hoy. Si falta informacion, pide "
    "solo lo imprescindible en una frase."
)


async def build_context(db: AsyncSession, user: User) -> dict[str, Any]:
    """Reune tareas, asignaturas, disponibilidad, horario y notas del estudiante."""
    now = utcnow()

    result = await db.execute(
        select(Task)
        .where(
            Task.user_id == user.id,
            Task.parent_task_id.is_(None),
            Task.status.in_([TaskStatus.pending, TaskStatus.in_progress]),
        )
        .order_by(Task.due_at.asc().nulls_last())
    )
    tasks = list(result.scalars().all())

    result = await db.execute(
        select(Course.id, Course.name).where(Course.user_id == user.id)
    )
    courses = {row.id: row.name for row in result.all()}

    result = await db.execute(
        select(ScheduleBlock).where(
            ScheduleBlock.user_id == user.id, ScheduleBlock.is_active.is_(True)
        )
    )
    blocks = list(result.scalars().all())

    result = await db.execute(
        select(TimetableEntry).where(TimetableEntry.user_id == user.id)
    )
    timetable = list(result.scalars().all())

    result = await db.execute(
        select(Grade).where(Grade.user_id == user.id)
    )
    grades = list(result.scalars().all())

    grade_by_course: dict[uuid.UUID | None, list[float]] = {}
    for grade in grades:
        if grade.percentage is not None:
            grade_by_course.setdefault(grade.course_id, []).append(grade.percentage)

    return {
        "now": now,
        "timezone": user.timezone or "UTC",
        "courses": list(courses.values()),
        "course_names": courses,
        "tasks": [
            {
                "title": t.title,
                "course": courses.get(t.course_id) if t.course_id else None,
                "due_at": t.due_at,
                "estimated_minutes": t.estimated_minutes,
                "priority": t.priority.value,
                "status": t.status.value,
            }
            for t in tasks
        ],
        "availability": [
            {
                "day_of_week": b.day_of_week,
                "start": b.start_time,
                "end": b.end_time,
                "label": b.label,
            }
            for b in blocks
        ],
        "timetable": [
            {
                "day_of_week": e.day_of_week,
                "start": e.start_time,
                "end": e.end_time,
                "course": (courses.get(e.course_id) if e.course_id else None) or e.title,
                "location": e.location,
            }
            for e in timetable
        ],
        "grades": [
            {
                "course": courses.get(course_id) if course_id else None,
                "average_percent": round(sum(values) / len(values), 2),
                "count": len(values),
            }
            for course_id, values in grade_by_course.items()
        ],
    }


def render_context_text(ctx: dict[str, Any]) -> str:
    """Convierte el contexto en texto legible para el prompt del modelo."""
    lines: list[str] = []
    now = ctx["now"]
    lines.append(
        f"Fecha y hora actual (UTC): {now.strftime('%Y-%m-%d %H:%M')}. "
        f"Zona horaria del estudiante: {ctx['timezone']}."
    )

    lines.append("\nASIGNATURAS: " + (", ".join(ctx["courses"]) or "(ninguna)"))

    if ctx["tasks"]:
        lines.append("\nTAREAS PENDIENTES (por fecha de entrega):")
        for t in ctx["tasks"]:
            due = t["due_at"].strftime("%Y-%m-%d %H:%M") if t["due_at"] else "sin fecha"
            course = t["course"] or "sin asignatura"
            lines.append(
                f"- {t['title']} [{course}] | entrega: {due} | "
                f"~{t['estimated_minutes']} min | prioridad: {t['priority']}"
            )
    else:
        lines.append("\nTAREAS PENDIENTES: (ninguna)")

    if ctx["availability"]:
        lines.append("\nDISPONIBILIDAD SEMANAL PARA ESTUDIAR:")
        for b in ctx["availability"]:
            lines.append(
                f"- {_DAYS[b['day_of_week']]} {b['start']:%H:%M}-{b['end']:%H:%M}"
                + (f" ({b['label']})" if b["label"] else "")
            )
    else:
        lines.append("\nDISPONIBILIDAD: (no definida)")

    if ctx["timetable"]:
        lines.append("\nHORARIO DE CLASES:")
        for e in ctx["timetable"]:
            lines.append(
                f"- {_DAYS[e['day_of_week']]} {e['start']:%H:%M}-{e['end']:%H:%M} "
                f"{e['course'] or 'Clase'}"
                + (f" en {e['location']}" if e["location"] else "")
            )

    if ctx["grades"]:
        lines.append("\nNOTAS (media por asignatura):")
        for g in ctx["grades"]:
            lines.append(f"- {g['course'] or 'Sin asignatura'}: {g['average_percent']}% ({g['count']})")

    return "\n".join(lines)


async def generate_reply(
    db: AsyncSession,
    user: User,
    message: str,
    history: list[dict[str, str]],
) -> tuple[str, str]:
    """Devuelve (texto, fuente) usando el modelo si esta disponible, si no el heuristico."""
    ctx = await build_context(db, user)

    if settings.ai_configured:
        try:
            system = f"{_SYSTEM_PROMPT}\n\nCONTEXTO DEL ESTUDIANTE:\n{render_context_text(ctx)}"
            reply = await _call_llm(system, history, message)
            if reply:
                return reply, "ai"
            logger.warning("El modelo devolvio una respuesta vacia; usando heuristico")
        except Exception as exc:  # noqa: BLE001 - degradacion controlada
            logger.warning("Asistente IA no disponible (%s); usando heuristico", exc)

    return heuristic_reply(ctx, message), "heuristic"


async def _call_llm(system: str, history: list[dict[str, str]], message: str) -> str:
    """Llama a un endpoint compatible con /chat/completions de OpenAI."""
    url = settings.ai_base_url.rstrip("/") + "/chat/completions"
    payload = {
        "model": settings.ai_model,
        "messages": [{"role": "system", "content": system}, *history, {"role": "user", "content": message}],
        "temperature": settings.ai_temperature,
        "stream": False,
    }
    headers = {"Content-Type": "application/json"}
    if settings.ai_api_key:
        headers["Authorization"] = f"Bearer {settings.ai_api_key}"

    async with httpx.AsyncClient(timeout=settings.ai_timeout_seconds) as client:
        response = await client.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

    choices = data.get("choices") or []
    if not choices:
        return ""
    return (choices[0].get("message", {}).get("content") or "").strip()


def heuristic_reply(ctx: dict[str, Any], message: str) -> str:
    """Recomendaciones por reglas: cuando empezar y que priorizar."""
    tasks = ctx["tasks"]
    if not tasks:
        return (
            "Ahora mismo no tienes tareas pendientes. Para poder ayudarte a organizarte, "
            "anade asignaturas y tareas (con su fecha de entrega y una estimacion de tiempo). "
            "En cuanto las tengas, te dire por donde empezar y que dias dedicar a cada cosa."
        )

    now = ctx["now"]
    lines = ["Este es mi plan recomendado basandome en tus tareas y disponibilidad:\n"]

    for t in tasks[:5]:
        course = t["course"] or "Sin asignatura"
        when = _urgency_label(t["due_at"], now)
        est = t["estimated_minutes"]
        lines.append(f"- {t['title']} ({course}): empieza {when}. Bloque de ~{est} min.")

    if len(tasks) > 5:
        lines.append(f"- y {len(tasks) - 5} tarea(s) mas, siguendo el mismo orden de entrega.")

    if ctx["availability"]:
        slots = ", ".join(
            f"{_DAYS[b['day_of_week']]} {b['start']:%H:%M}-{b['end']:%H:%M}"
            for b in ctx["availability"][:3]
        )
        lines.append(f"\nUsa tus franjas disponibles ({slots}) y trabaja primero lo mas urgente.")
    else:
        lines.append(
            "\nNo has definido disponibilidad; marcala en Ajustes para que pueda repartir tu tiempo."
        )

    lines.append(
        "\nNota: no he podido usar el modelo de IA local (revisa que Ollama este activo), "
        "asi que te respondo con el motor de reglas."
    )
    return "\n".join(lines)


def _urgency_label(due_at: datetime | None, now: datetime) -> str:
    if due_at is None:
        return "cuando antes tengas un hueco"
    hours = (due_at - now).total_seconds() / 3600
    if hours <= 0:
        return "ya, la entrega esta vencida o es inminente"
    if hours <= 72:
        return "hoy mismo"
    if hours <= 24 * 7:
        return "en los proximos 2 dias"
    return "esta semana sin agobios"
