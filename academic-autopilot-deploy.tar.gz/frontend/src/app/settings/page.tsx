"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Loader2, Link2, Plus, Trash2 } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { api, ApiError } from "@/lib/api";
import type { Integration, ScheduleBlock } from "@/lib/types";

const DAYS = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"];

const PROVIDER_LABEL: Record<string, string> = {
  moodle: "Moodle",
  google_classroom: "Google Classroom",
};

function SettingsInner() {
  const searchParams = useSearchParams();

  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [blocks, setBlocks] = useState<ScheduleBlock[]>([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  // Formulario Moodle
  const [moodleUrl, setMoodleUrl] = useState("");
  const [moodleToken, setMoodleToken] = useState("");

  // Formulario de disponibilidad
  const [day, setDay] = useState(0);
  const [start, setStart] = useState("16:30");
  const [end, setEnd] = useState("20:30");
  const [label, setLabel] = useState("Tarde de estudio");

  const loadData = useCallback(async () => {
    const [ints, sbs] = await Promise.all([api.integrations(), api.scheduleBlocks()]);
    setIntegrations(ints);
    setBlocks(sbs);
  }, []);

  useEffect(() => {
    loadData().catch((e) => setNotice(e instanceof Error ? e.message : "Error"));
  }, [loadData]);

  // Maneja el retorno de OAuth2 de Google (?code=...).
  useEffect(() => {
    const code = searchParams.get("code");
    if (!code) return;
    setBusy(true);
    api
      .connectGoogle({ code, state: searchParams.get("state") ?? undefined })
      .then(() => {
        setNotice("Google Classroom conectado");
        return loadData();
      })
      .catch((e) => setNotice(e instanceof Error ? e.message : "Error al conectar Google"))
      .finally(() => {
        setBusy(false);
        // Limpia el ?code de la URL.
        window.history.replaceState({}, "", "/settings");
      });
  }, [searchParams, loadData]);

  async function connectMoodle(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setNotice(null);
    try {
      await api.connectMoodle({ base_url: moodleUrl, token: moodleToken });
      setNotice("Moodle conectado");
      setMoodleUrl("");
      setMoodleToken("");
      await loadData();
    } catch (e) {
      setNotice(e instanceof ApiError ? e.message : "Error al conectar Moodle");
    } finally {
      setBusy(false);
    }
  }

  async function connectGoogle() {
    setBusy(true);
    setNotice(null);
    try {
      const { authorization_url } = await api.googleAuthorizeUrl();
      window.location.href = authorization_url;
    } catch (e) {
      setNotice(e instanceof ApiError ? e.message : "Error al iniciar OAuth de Google");
      setBusy(false);
    }
  }

  async function disconnect(id: string) {
    await api.disconnect(id);
    await loadData();
  }

  async function addBlock(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      await api.createBlock({
        day_of_week: day,
        start_time: start,
        end_time: end,
        label: label || null,
        is_active: true,
      });
      await loadData();
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Error al crear bloque");
    } finally {
      setBusy(false);
    }
  }

  async function removeBlock(id: string) {
    await api.deleteBlock(id);
    await loadData();
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 p-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Ajustes</h1>
        <p className="text-sm text-muted-foreground">
          Conecta tus plataformas y define tu disponibilidad semanal.
        </p>
      </header>

      {notice && (
        <div className="rounded-md border border-border bg-secondary/40 px-4 py-2 text-sm">
          {notice}
        </div>
      )}

      {/* ---- Integraciones ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Link2 className="h-4 w-4" /> Plataformas conectadas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {integrations.map((integration) => (
            <div
              key={integration.id}
              className="flex items-center justify-between rounded-md border border-border/60 px-3 py-2"
            >
              <div>
                <p className="text-sm">{PROVIDER_LABEL[integration.provider] ?? integration.provider}</p>
                <p className="text-xs text-muted-foreground">
                  {integration.base_url ?? (integration.meta?.username as string) ?? ""}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={integration.status === "connected" ? "success" : "destructive"}>
                  {integration.status}
                </Badge>
                <Button variant="ghost" size="icon" onClick={() => disconnect(integration.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
          {integrations.length === 0 && (
            <p className="text-sm text-muted-foreground">Aun no hay plataformas conectadas.</p>
          )}

          {/* Moodle */}
          <form onSubmit={connectMoodle} className="space-y-3 rounded-md border border-border/60 p-3">
            <p className="text-sm font-medium">Conectar Moodle</p>
            <div className="space-y-2">
              <Label htmlFor="moodleUrl">URL de tu Moodle</Label>
              <Input
                id="moodleUrl"
                placeholder="https://moodle.universidad.edu"
                value={moodleUrl}
                onChange={(e) => setMoodleUrl(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="moodleToken">Token de Web Services</Label>
              <Input
                id="moodleToken"
                placeholder="Perfil > Seguridad > Claves de acceso"
                value={moodleToken}
                onChange={(e) => setMoodleToken(e.target.value)}
                required
              />
            </div>
            <Button type="submit" size="sm" disabled={busy}>
              Guardar Moodle
            </Button>
          </form>

          {/* Google */}
          <div className="flex items-center justify-between rounded-md border border-border/60 p-3">
            <div>
              <p className="text-sm font-medium">Conectar Google Classroom</p>
              <p className="text-xs text-muted-foreground">Autoriza con tu cuenta de Google.</p>
            </div>
            <Button size="sm" onClick={connectGoogle} disabled={busy}>
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} Autorizar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* ---- Disponibilidad ---- */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Disponibilidad semanal</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={addBlock} className="grid gap-3 sm:grid-cols-5 sm:items-end">
            <div className="space-y-2">
              <Label>Dia</Label>
              <select
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                value={day}
                onChange={(e) => setDay(Number(e.target.value))}
              >
                {DAYS.map((d, i) => (
                  <option key={d} value={i} className="bg-background">
                    {d}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label>Desde</Label>
              <Input type="time" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Hasta</Label>
              <Input type="time" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Etiqueta</Label>
              <Input value={label} onChange={(e) => setLabel(e.target.value)} />
            </div>
            <Button type="submit" disabled={busy}>
              <Plus className="h-4 w-4" /> Anadir
            </Button>
          </form>

          <div className="space-y-2">
            {blocks.map((block) => (
              <div
                key={block.id}
                className="flex items-center justify-between rounded-md border border-border/60 px-3 py-2 text-sm"
              >
                <span>
                  <span className="font-medium">{DAYS[block.day_of_week]}</span>{" "}
                  <span className="text-muted-foreground">
                    {block.start_time.slice(0, 5)}–{block.end_time.slice(0, 5)}
                  </span>
                  {block.label && <span className="text-muted-foreground"> · {block.label}</span>}
                </span>
                <Button variant="ghost" size="icon" onClick={() => removeBlock(block.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
            {blocks.length === 0 && (
              <p className="text-sm text-muted-foreground">
                Sin disponibilidad definida. Ej: tardes de 16:30 a 20:30.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SettingsPage() {
  return (
    <Suspense fallback={<div className="p-6 text-muted-foreground">Cargando ajustes...</div>}>
      <SettingsInner />
    </Suspense>
  );
}
