"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Bot, Loader2, Send, Sparkles, Trash2, User as UserIcon } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { api, ApiError } from "@/lib/api";
import type { AssistantMessage, AssistantStatus } from "@/lib/types";

const QUICK_PROMPTS = [
  "¿Cuándo empiezo a estudiar?",
  "Organiza mi semana",
  "¿Qué priorizo hoy?",
  "Ayúdame a planificar un trabajo largo",
];

function errorMessage(error: unknown): string {
  if (error instanceof ApiError) return error.message;
  if (error instanceof Error) return error.message;
  return "Error inesperado";
}

export default function AssistantPage() {
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [status, setStatus] = useState<AssistantStatus | null>(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    const [history, st] = await Promise.all([
      api.assistantMessages(100),
      api.assistantStatus(),
    ]);
    setMessages(history);
    setStatus(st);
  }, []);

  useEffect(() => {
    load()
      .catch((e) => setError(errorMessage(e)))
      .finally(() => setLoading(false));
  }, [load]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  const send = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || sending) return;
      setSending(true);
      setError(null);
      setInput("");
      setMessages((prev) => [
        ...prev,
        {
          id: `tmp-${Date.now()}`,
          role: "user",
          content: trimmed,
          source: null,
          created_at: new Date().toISOString(),
        },
      ]);
      try {
        await api.chat(trimmed);
        setMessages(await api.assistantMessages(100));
      } catch (e) {
        setError(errorMessage(e));
        try {
          setMessages(await api.assistantMessages(100));
        } catch {
          /* ignore */
        }
      } finally {
        setSending(false);
      }
    },
    [sending],
  );

  async function clearHistory() {
    try {
      await api.clearAssistant();
      setMessages([]);
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  function onKeyDown(event: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      send(input);
    }
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4 p-6">
      <header className="flex items-start justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
            <Sparkles className="h-6 w-6 text-primary" /> Asistente IA
          </h1>
          <p className="text-sm text-muted-foreground">
            Tu tutora de organizacion: te dice cuando empezar a estudiar y como repartir tu tiempo,
            usando tus tareas, horario y disponibilidad.
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={clearHistory} disabled={messages.length === 0}>
          <Trash2 className="h-4 w-4" /> Limpiar
        </Button>
      </header>

      {status && !status.configured && (
        <div className="rounded-md border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm">
          El modelo de IA no esta configurado. Para usar Ollama: instala Ollama, ejecuta{" "}
          <code className="rounded bg-secondary px-1">ollama pull {status.model}</code> y define{" "}
          <code className="rounded bg-secondary px-1">AI_BASE_URL</code> en tu <code>.env</code>.
          Mientras tanto respondere con el motor de reglas.
        </div>
      )}

      {error && (
        <div className="rounded-md border border-destructive/40 bg-destructive/10 px-4 py-2 text-sm">
          {error}
        </div>
      )}

      <Card className="flex-1">
        <CardContent className="flex h-[62vh] flex-col gap-4 p-4">
          <div className="flex-1 space-y-4 overflow-y-auto pr-1">
            {loading && <p className="text-sm text-muted-foreground">Cargando conversacion...</p>}

            {!loading && messages.length === 0 && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Pregunta lo que quieras sobre tu estudio. Por ejemplo:
                </p>
                <div className="flex flex-wrap gap-2">
                  {QUICK_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => send(prompt)}
                      className="rounded-full border border-border px-3 py-1 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((message) => {
              const isUser = message.role === "user";
              return (
                <div
                  key={message.id}
                  className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}
                >
                  <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary">
                    {isUser ? <UserIcon className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                  </div>
                  <div
                    className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                      isUser ? "bg-primary/10" : "bg-secondary/50"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{message.content}</p>
                    {!isUser && message.source && (
                      <div className="mt-2">
                        <Badge variant={message.source === "ai" ? "success" : "warning"}>
                          {message.source === "ai"
                            ? `IA · ${status?.model ?? ""}`
                            : "Reglas locales"}
                        </Badge>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {sending && (
              <div className="flex gap-3">
                <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary">
                  <Bot className="h-4 w-4" />
                </div>
                <div className="flex items-center gap-2 rounded-lg bg-secondary/50 px-3 py-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Pensando...
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          <div className="flex items-end gap-2 border-t pt-3">
            <textarea
              className="min-h-[44px] flex-1 resize-none rounded-md border border-input bg-transparent px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-ring"
              placeholder="Escribe tu pregunta... (Enter para enviar, Shift+Enter para salto de linea)"
              rows={2}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
              disabled={sending}
            />
            <Button onClick={() => send(input)} disabled={sending || !input.trim()}>
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              Enviar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
